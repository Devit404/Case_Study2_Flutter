

class UserProfile{
  String name;
  String email;
  String mobile;
  String dob;
  UserProfile({required this.name,required this.email,required this.mobile,required this.dob
  });
}